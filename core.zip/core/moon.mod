name = "moonbitlang/core"

version = "0.10.2+1bb3e16cf"

readme = "README.md"

repository = "https://github.com/moonbitlang/core"

license = "Apache-2.0"

keywords = [ "core", "standard library" ]

warnings = "+test_unqualified_package+unqualified_local_using+missing_doc+unnecessary_view_op+unnecessary_annotation+prefer_fixed_array+prefer_readonly_array"
