# Immutable Set

ImmutableSet is an immutable, persistent implementation of the set structure (each operation returns a new ImmutableSet), implemented here using a balance tree.

# Usage

## Create

Since set is based on comparison, the type used to construct ImmutableSet needs to implement Compare trait.

You can create an empty ImmutableSet with a value separately through the following methods, or create it directly from the Array.

```mbt check
///|
test {
  let _set1 : @sorted_set.SortedSet[Int] = @sorted_set.new()
  let _set2 = @sorted_set.singleton(1)
  let _set4 = @sorted_set.from_array([1])
  let _set5 = @sorted_set.from_array([1])
}
```

## Conversion

You can convert an immutable set to an array, which will be sorted.

```mbt check
///|
test {
  let set = @sorted_set.from_array([3, 2, 1])
  @test.assert_eq(set.to_array(), [1, 2, 3])
}
```

## Add & Remove

You can use `add` to add an element to the ImmutableSet.

```mbt check
///|
test {
  let set = @sorted_set.from_array([1, 2, 3, 4])
  @test.assert_eq(set.add(5).to_array(), [1, 2, 3, 4, 5])
}
```

You can use `remove` to remove a specific value.

```mbt check
///|
test {
  let set = @sorted_set.from_array([3, 8, 1])
  @test.assert_eq(set.remove(8).to_array(), [1, 3])
}
```

## Max & Min & Contains

You can use `contains` to query whether an element is in the set.

```mbt check
///|
test {
  let set = @sorted_set.from_array([1, 2, 3, 4])
  @test.assert_eq(set.contains(1), true)
  @test.assert_eq(set.contains(5), false)
}
```

You can also use `min` and `max` to obtain the minimum or maximum value in the set. When the set is empty, an error will be reported, and they have corresponding Option versions to handle this.

```mbt check
///|
test {
  let set = @sorted_set.from_array([1, 2, 3, 4])
  @test.assert_eq(set.min(), 1)
  @test.assert_eq(set.max(), 4)
  @test.assert_eq(set.min_option(), Some(1))
  @test.assert_eq(set.max_option(), Some(4))
}
```

## Split & Union & Inter & Diff & Filter

You can provide an intermediate value to divide a set into two sets by `split`, and whether the intermediate value is in the set will also be returned as the return value.

```mbt check
///|
test {
  let (left, present, right) = @sorted_set.from_array([
    7, 2, 9, 4, 5, 6, 3, 8, 1,
  ]).split(5)
  @test.assert_eq(present, true)
  @test.assert_eq(left.to_array(), [1, 2, 3, 4])
  @test.assert_eq(right.to_array(), [6, 7, 8, 9])
}
```

At the same time, you can use union and inter to take the union or intersection of two sets.

```mbt check
///|
test {
  let set1 = @sorted_set.from_array([3, 4, 5])
  let set2 = @sorted_set.from_array([4, 5, 6])
  @test.assert_eq(set1.union(set2).to_array(), [3, 4, 5, 6])
  @test.assert_eq(set1.intersection(set2).to_array(), [4, 5])
}
```

You can also use the `diff` function to obtain the difference between two sets.

```mbt check
///|
test {
  let set1 = @sorted_set.from_array([1, 2, 3])
  let set2 = @sorted_set.from_array([4, 5, 1])
  @test.assert_eq(set1.difference(set2).to_array(), [2, 3])
}
```

You can use `filter` to filter the elements in the set.

```mbt check
///|
test {
  let set = @sorted_set.from_array([1, 2, 3, 4, 5, 6])
  @test.assert_eq(set.filter(v => v % 2 == 0).to_array(), [2, 4, 6])
}
```

## Subset & Disjoint

You can use `subsets` and `disjoint` to determine the inclusion and separation relationship between two sets

```mbt check
///|
test {
  @test.assert_eq(
    @sorted_set.from_array([1, 2, 3]).subset(
      @sorted_set.from_array([7, 2, 9, 4, 5, 6, 3, 8, 1]),
    ),
    true,
  )
  @test.assert_eq(
    @sorted_set.from_array([1, 2, 3]).disjoint(
      @sorted_set.from_array([4, 5, 6]),
    ),
    true,
  )
}
```

## Iter & Fold & Map

Like other sequential containers, set also has iterative methods such as `iter`, `fold`, and `map`, and their order is based on the comparison being less than the order.

```mbt check
///|
test {
  let arr = []
  @sorted_set.from_array([7, 2, 9, 4, 5, 6, 3, 8, 1]).each(v => arr.push(v))
  @test.assert_eq(arr, [1, 2, 3, 4, 5, 6, 7, 8, 9])
  let val = @sorted_set.from_array([1, 2, 3, 4, 5]).fold(init=0, (acc, x) => {
    acc + x
  })
  @test.assert_eq(val, 15)
  let set = @sorted_set.from_array([1, 2, 3])
  @test.assert_eq(set.map(x => x * 2).to_array(), [2, 4, 6])
}
```

You can also use `rev_iter()` to iterate in descending order.

```mbt check
///|
test {
  let set = @sorted_set.from_array([1, 2, 3, 4, 5])
  let arr = []
  set.rev_iter().each(v => arr.push(v))
  @test.assert_eq(arr, [5, 4, 3, 2, 1])
}
```

## All & Any

`all` and `any` can detect whether all elements in the set match or if there are elements that match.

```mbt check
///|
test {
  @test.assert_eq(@sorted_set.from_array([2, 4, 6]).all(v => v % 2 == 0), true)
  @test.assert_eq(@sorted_set.from_array([1, 4, 3]).any(v => v % 2 == 0), true)
}
```

## Empty

`is_empty` can determine whether a set is empty.

```mbt check
///|
test {
  let set1 : @sorted_set.SortedSet[Int] = @sorted_set.from_array([])
  @test.assert_eq(set1.is_empty(), true)
  let set2 = @sorted_set.from_array([1])
  @test.assert_eq(set2.is_empty(), false)
}
```
